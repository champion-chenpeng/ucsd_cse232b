# XPath Notes
0. project construction
	- see project architecture
	- parser -> construct XML tree from text file
	- evaluator: 
1. XPath Semantic
(absolute path) ap -> doc(fileName)/rp
					| doc(
