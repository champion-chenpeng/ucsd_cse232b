# XQuery Theory
## C
	- record all variable bindings in an auxiliary data structure called a context
## C(Var)
	- The value of Var in context C
## Before clause
main logic:
- C -> C(Var)
- makeXXX()
- some logic similar to xpath

## Clause

## Cond

